opportunities.py

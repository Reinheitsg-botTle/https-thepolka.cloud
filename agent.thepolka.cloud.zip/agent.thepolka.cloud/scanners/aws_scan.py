aws_scan.py

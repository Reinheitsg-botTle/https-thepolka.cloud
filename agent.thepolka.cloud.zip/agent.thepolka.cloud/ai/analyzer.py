analyzer.py

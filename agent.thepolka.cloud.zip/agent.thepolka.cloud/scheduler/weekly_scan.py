weekly_scan.py
